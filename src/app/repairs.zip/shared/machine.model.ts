export class MachineType {
    Machine_No: string;
    Machine_Name: string;
    DateRecieve: Date;
    Qty: number;
    Brand: string;
    Generation: string;
    Energy: string;
    Location: string;
    Note: string;
}