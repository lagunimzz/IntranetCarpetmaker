export class EquipmentType {
    ID: string;
    TypeName: string;
    Category: string;
}