import { Component, OnInit } from '@angular/core';
import { Repair } from './shared/repair.model';
import { RepairService } from './shared/repair.service';

@Component({
  selector: 'app-repair',
  templateUrl: './repair.component.html',
  styleUrls: ['./repair.component.css']
})
export class RepairComponent  {}
